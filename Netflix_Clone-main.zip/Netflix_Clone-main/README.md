# Netflix_Clone
Netflix front end clone desktop version usign html and css
check this website at this link;-   https://ritesh-0309.github.io/Netflix_Clone/
